# Repository Map

This repository is organized as a product archive rather than only a source-code folder.

| Path | Purpose | Status |
|---|---|---|
| `README.md` | Public project overview and portfolio entry point | Current |
| `LICENSE` | MIT license | Current |
| `.gitignore` | Secret/build/private-file protection | Current |
| `REPOSITORY_MAP.md` | Structure guide | Current |
| `docs/` | Core product and case-study documentation | Current |
| `01-project-overview/` | Product definition and scope | Documentation |
| `02-branding/` | Brand system and identity references | Documentation |
| `03-ui-ux/` | UX principles, screens, and interface direction | Documentation / prototype |
| `04-website-app/` | Public web experience and application direction | Prototype / implementation archive |
| `05-ai-automation/` | AI assistant and automation architecture | Concept / planned |
| `06-game-concept/` | Sonagazi Mart City Delivery game concept | Concept |
| `07-prompts/` | Reusable product/design/AI prompts | Archive |
| `08-database/` | Data model and database planning | Planned |
| `09-deployment/` | Deployment and environment notes | Current / planned |
| `10-marketing/` | Marketing and launch materials | Archive |
| `11-progress/` | Progress tracking and status | Current |

## Status vocabulary

- **Current** — publicly observable or already documented in the project.
- **Prototype** — demonstrated as a UI/product prototype, not necessarily production-ready.
- **Concept** — product idea or architecture being explored.
- **Planned** — intended future implementation.
- **Archive** — supporting material retained for project history.
