# Deployment Notes

## Current Public Deployment

`https://sonagazi-five.vercel.app`

The live project is currently presented as a demo experience.

## GitHub

`https://github.com/rahima8581-ops/Sonagazi-mart-`

## Environment Variables

Sensitive configuration belongs in the deployment provider's environment settings.

Never commit:

- `.env`
- API keys
- database URLs containing credentials
- bot tokens
- private webhook URLs
- service-account keys

The repository `.gitignore` is configured to reduce accidental secret commits.

## Future Production Checklist

- [ ] Production domain
- [ ] Secure authentication
- [ ] Database
- [ ] Server-side validation
- [ ] Payment provider
- [ ] Order-state system
- [ ] Inventory synchronization
- [ ] Rider workflow
- [ ] Monitoring
- [ ] Error tracking
- [ ] Backup strategy
- [ ] Privacy policy review
- [ ] Terms and returns review
