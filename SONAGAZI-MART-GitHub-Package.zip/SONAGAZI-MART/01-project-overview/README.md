# 01 — Project Overview

Product definition, scope, user roles, principles, and current-vs-planned status.

See [`docs/PROJECT_DOCUMENTATION.md`](../docs/PROJECT_DOCUMENTATION.md).
