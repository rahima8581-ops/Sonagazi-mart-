# 07 — Prompts

Reusable prompts and creative direction developed for Sonagazi Mart.

Suggested organization:
- `image-prompts.md`
- `video-prompts.md`
- `ai-automation-prompts.md`
- `ui-prompts.md`

Only prompts that are safe to publish and free of credentials or private data should be committed.
