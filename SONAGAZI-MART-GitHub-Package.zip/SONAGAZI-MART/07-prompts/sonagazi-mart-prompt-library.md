# Sonagazi Mart Prompt Library

This file records reusable creative directions without storing credentials or private information.

## Premium Product UI

Create a clean, modern marketplace interface for Sonagazi Mart with strong product hierarchy, readable pricing, local delivery context, responsive layout, and the brand palette:
- `#16A34A`
- `#14532D`
- `#FFFFFF`
- `#D4AF37`

Avoid generic template styling, excessive gradients, and unsupported claims.

## AI Customer Support

Design an AI customer-support workflow for Sonagazi Mart that answers in Bengali, English, or Banglish based on the customer. The assistant must use approved product data for product names, prices, and stock. If data is unavailable, it must say so rather than inventing an answer.

## City Delivery Game

Design a realistic 3D mobile delivery simulator concept called **SONAGAZI MART — CITY DELIVERY**. Use a believable Bangladeshi town environment with roads, concrete buildings, local shops, utility poles and wires, rickshaws, motorcycles, cars, buses, pedestrians, and Sonagazi Mart branding. Keep it realistic rather than cartoonish.

## Content Automation

Create a premium AI commerce automation concept showing:

`Website / Telegram / WhatsApp → AI Agent → Sonagazi Mart → Business Data → Customer Response`

Use a modern SaaS/product-technology visual language without fabricating real integration status.
