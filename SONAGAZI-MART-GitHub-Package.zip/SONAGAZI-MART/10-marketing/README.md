# 10 — Marketing

Marketing and brand communication archive.

Content direction:
- Local-first
- Clear
- Modern
- Helpful
- Professional
- Bengali-first when appropriate

Avoid unsupported claims and fake urgency.
