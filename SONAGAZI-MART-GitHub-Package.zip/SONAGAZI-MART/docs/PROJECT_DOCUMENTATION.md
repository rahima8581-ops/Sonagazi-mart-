# Project Documentation

## 1. Product

**Name:** Sonagazi Mart  
**Slogan:** Everything You Need, Delivered Fast.  
**Location:** Sonagazi, Feni, Bangladesh  
**Founder:** H.M. Tahsin — Founder & CEO

Sonagazi Mart is a local-commerce product concept focused on making everyday shopping and delivery easier in Sonagazi.

## 2. Product Scope

The platform is designed around several connected surfaces:

- Customer marketplace
- Product discovery
- Cart and order experience
- Local delivery
- Shop operations
- Rider operations
- Administration
- AI customer support
- Workflow automation
- Messaging channels

Not all surfaces are currently production implementations.

## 3. Public Web Experience

The public deployment presents:

- Sonagazi-focused delivery messaging
- Marketplace categories
- Product discovery
- Offers
- Cart/order navigation
- About/contact/FAQ/legal navigation
- Mobile app concept presentation
- Admin demo navigation

The live site labels itself as a demo experience, so this repository preserves that distinction.

## 4. Product Principles

1. Local-first
2. Clear product information
3. Reliable pricing and stock data
4. Simple ordering
5. Human-readable customer support
6. Automation with controlled data
7. Privacy and credential safety
8. Honest documentation of prototype vs production status

## 5. Roles

### Customer
Browses products, evaluates availability, places orders, receives support, and tracks delivery.

### Rider
Receives delivery tasks, picks up orders, updates status, and confirms delivery.

### Shop
Manages products, stock, pricing, preparation, and incoming orders.

### Admin
Manages platform operations, catalog, users, orders, shops, riders, and configuration.

### AI Assistant
Answers customer questions using approved business data and escalates when information is unavailable or uncertain.

## 6. Product Data

The product system should treat these as authoritative business fields:

- Product ID
- Product name
- Category
- Unit
- Price
- Discount
- Stock status
- Shop
- Availability
- Product description
- Image
- Updated timestamp

The AI assistant should not create values that are missing from the authoritative source.

## 7. Non-Goals

This repository does not claim that the following are already production-ready:

- Real payment processing
- Real customer authentication
- Production rider dispatch
- Production merchant onboarding
- Live WhatsApp automation
- Live Telegram automation
- Production AI inventory access
- Real-time logistics tracking
