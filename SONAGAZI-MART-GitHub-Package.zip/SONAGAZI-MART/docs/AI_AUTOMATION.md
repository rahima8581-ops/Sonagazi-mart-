# AI Support & Sales Automation

## Purpose

The Sonagazi Mart AI Support & Sales Assistant is a planned automation layer for customer support and product discovery.

It should support:

- Bengali
- English
- Banglish

The assistant should prioritize accuracy over pretending to know an answer.

## Core Workflow

```text
Customer
   │
   ├── Website
   ├── Telegram
   └── WhatsApp
          │
          ▼
     Message Intake
          │
          ▼
       n8n Workflow
          │
          ▼
       AI Agent
          │
          ├── Product Lookup
          ├── Stock Lookup
          ├── Price Lookup
          └── Order / Support Intent
          │
          ▼
   Approved Business Data
          │
          ▼
      Customer Reply
```

## Product Database

The AI assistant should use a structured product source as the authority for:

- Product name
- Category
- Current price
- Discount
- Stock/availability
- Unit
- Shop
- Product identifier

## Customer Chat

The assistant can understand requests such as:

- “চাল আছে?”
- “Miniket rice কত?”
- “Apple আছে?”
- “What groceries are available?”
- “এই পণ্যটা কত কেজি?”
- “Banglish” mixed-language questions

The response language can follow the customer's language where practical.

## Accuracy Rules

The assistant must **never**:

- Invent a product
- Invent a price
- Invent stock availability
- Claim a discount that is not in the data
- Pretend an order was placed when it was not
- Claim a delivery status it cannot verify
- Reveal private customer or operational information

When data is missing, the assistant should say that the information is unavailable or request clarification.

## n8n Workflow Concept

A possible n8n workflow:

1. Receive message
2. Identify channel
3. Normalize message
4. Detect intent
5. Query approved product/order data
6. Send relevant context to AI
7. Validate response against available data
8. Return response
9. Log non-sensitive operational metadata
10. Escalate to human support when necessary

## Telegram Integration

**Concept / planned**

Telegram can act as an inbound/outbound customer-support channel.

Possible flow:

`Telegram Message → n8n → AI Agent → Product Data → Telegram Reply`

Credentials must remain in n8n's secure credential store or environment configuration, never in Git.

## WhatsApp Integration

**Concept / planned**

WhatsApp can provide a customer-support and sales channel.

Possible flow:

`WhatsApp Message → Integration Provider → n8n → AI Agent → Approved Data → Reply`

The exact provider and production API setup should be documented only after implementation.

## Website Assistant

**Concept / planned**

The web interface can provide an embedded assistant for:

- Product questions
- Availability questions
- Basic shopping guidance
- Order-support routing

## Security

Never commit:

- API keys
- Bot tokens
- Access tokens
- Passwords
- Private webhook URLs
- Database credentials
- Customer phone numbers
- Customer addresses
- Private chat logs

Use environment variables and platform credential managers.

## Human Handoff

The system should hand off to a human when:

- The customer asks for an action the AI cannot safely perform.
- Product data is unavailable.
- Stock status is ambiguous.
- An order requires manual intervention.
- A complaint or sensitive issue needs human support.
