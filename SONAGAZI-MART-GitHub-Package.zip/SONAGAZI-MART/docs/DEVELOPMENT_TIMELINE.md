# Development Timeline

## Phase 1 — Idea

**Goal:** Define a local digital commerce concept for Sonagazi.

Output:
- Sonagazi Mart name
- Local marketplace direction
- Delivery-first positioning
- Slogan: “Everything You Need, Delivered Fast.”

## Phase 2 — Product Concept

The project expanded from a simple grocery idea into a broader local marketplace concept.

Explored areas:
- Grocery
- Fresh produce
- Pharmacy
- Electronics
- Fashion
- Home essentials
- Local delivery

## Phase 3 — UI/UX

The interface direction was developed around:

- Clean marketplace layouts
- Product cards
- Category navigation
- Offers
- Cart/order flows
- Local delivery messaging
- Mobile-first presentation

## Phase 4 — Web Development

A public Vercel deployment was developed to demonstrate the Sonagazi Mart experience.

The current deployment is explicitly presented as a demo experience.

## Phase 5 — AI

The product direction expanded to include:

- AI customer support
- Product discovery
- Product lookup
- Stock lookup
- Price lookup
- Bengali / English / Banglish interaction

## Phase 6 — Automation

n8n became the planned orchestration layer for connecting customer channels, AI processing, business data, and operational workflows.

## Phase 7 — Messaging Integrations

Telegram and WhatsApp were explored as possible customer-support channels.

These integrations remain concepts/planned architecture unless implementation is separately documented.

## Phase 8 — Game Concept

A separate **SONAGAZI MART — CITY DELIVERY** concept was developed as a realistic 3D delivery simulator direction.

This is a product/brand experiment, not a claim that a production game exists.

## Phase 9 — Public Archive

The project is organized into a GitHub repository so the development journey can be reviewed as a professional product case study.

## Documentation Principle

The repository intentionally separates:

- Implemented/publicly observable work
- Prototype work
- Concepts
- Planned integrations
- Future roadmap

This prevents portfolio documentation from overstating the current implementation.
