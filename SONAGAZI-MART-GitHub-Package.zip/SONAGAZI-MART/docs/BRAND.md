# Brand Guidelines

## Brand

**SONAGAZI MART**

**Slogan:** Everything You Need, Delivered Fast.

## Founder

**H.M. Tahsin — Founder & CEO — Sonagazi Mart**

## Credit

**BUILT BY H.M. TAHSIN**

## Location

Sonagazi, Feni, Bangladesh

## Color Palette

| Role | Color | Hex |
|---|---|---|
| Primary Green | Brand / action | `#16A34A` |
| Dark Green | Deep brand tone | `#14532D` |
| White | Background / contrast | `#FFFFFF` |
| Gold Accent | Premium accent | `#D4AF37` |

## Visual Direction

The brand should feel:

- Local
- Modern
- Reliable
- Clean
- Practical
- Premium without being excessive

## Typography

Use a clean, highly readable sans-serif system for digital interfaces.

For Bengali content, choose a Unicode-safe Bengali font with strong readability.

## Messaging

Preferred:
- Clear
- Helpful
- Specific
- Human
- Local

Avoid:
- Spammy urgency
- Fake scarcity
- Unsupported claims
- Overpromising delivery
- Unverified “best” or “number one” language

## Brand Usage

The brand should consistently present:

**SONAGAZI MART**  
**Everything You Need, Delivered Fast.**

Founder credit:

**BUILT BY H.M. TAHSIN**
