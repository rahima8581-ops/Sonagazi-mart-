# 04 — Website / App

Public web experience and application direction.

Live demo:
https://sonagazi-five.vercel.app

The public deployment currently presents a demo marketplace experience. Production backend, payment, authentication, and operational integrations should not be assumed unless separately documented.
