# SONAGAZI MART

**Everything You Need, Delivered Fast.**

A modern grocery and delivery platform built for Sonagazi, Feni, Bangladesh.

> **Project status:** Public web demo / product prototype. Some systems described in this repository are concepts, planned integrations, experiments, or future product modules rather than completed production features.

---

## Project Overview

**Sonagazi Mart** is a local-first digital commerce concept designed around everyday shopping and delivery in Sonagazi, Feni.

The product direction combines:

- Online shopping and product discovery
- Local delivery
- Customer, rider, shop, and admin experiences
- AI-assisted customer support and sales
- Workflow automation with n8n
- Messaging integrations such as Telegram and WhatsApp
- A future realistic delivery-game concept for brand/product experimentation

The public web experience currently presents a marketplace-style demo with categories, offers, product discovery, cart/order flows, delivery messaging, and an admin-demo entry point.

## Vision

Build a practical digital marketplace for Sonagazi that makes everyday shopping simpler while creating a foundation for local merchants, delivery operations, customer support, and automation.

The long-term direction is:

**Discover → Order → Prepare → Deliver → Support → Improve**

## Features

### Customer Experience

The current public demo communicates a local marketplace experience with:

- Product categories
- Product cards and offers
- Shopping/cart-oriented flows
- Order and tracking navigation
- Local delivery messaging
- About/contact/FAQ/legal navigation
- Mobile-app concept presentation

Production-grade payment, authentication, fulfillment, and operational integrations should be treated as future implementation work unless explicitly marked otherwise in the repository.

### Rider System

**Concept / planned module**

A rider workflow can eventually cover:

1. Rider availability
2. Order assignment
3. Pickup confirmation
4. Delivery route/status
5. Customer contact
6. Delivery confirmation
7. Operational history

No claim is made here that a complete production rider system is currently implemented.

### Shop Dashboard

**Concept / planned module**

A merchant/shop dashboard can provide:

- Product management
- Stock updates
- Price management
- Incoming orders
- Order preparation status
- Sales overview
- Product availability for the AI assistant

### Admin Dashboard

**Concept / prototype direction**

The product direction includes an administrative layer for:

- Orders
- Products
- Categories
- Users
- Riders
- Shops
- Operations
- Promotions
- Platform configuration

The public site currently exposes an **Admin Demo** navigation entry; this should not be interpreted as a production-ready admin backend.

### AI Support & Sales Assistant

**Concept / planned integration**

The AI assistant is designed to help customers discover products and receive support in Bengali, English, and Banglish.

Core safety/data rules:

- Look up products from an approved product source.
- Look up current price from an approved data source.
- Look up stock from an approved data source.
- Never invent products.
- Never invent prices.
- Never invent stock availability.
- Clearly say when information is unavailable.

See [`docs/AI_AUTOMATION.md`](docs/AI_AUTOMATION.md).

### n8n Automation

**Concept / planned architecture**

n8n is intended to orchestrate workflows between customer channels, AI processing, business data, and operational systems.

Example direction:

`Telegram / WhatsApp / Website → AI Agent → Product Data → Response / Order Workflow`

No credentials, tokens, private webhook URLs, or customer data are stored in this repository.

## Technology Stack

The project direction may use:

- Modern web frontend
- Responsive UI/UX
- Vercel deployment
- Structured product data
- Database-backed inventory and orders
- AI services
- n8n workflow automation
- Telegram integration
- WhatsApp integration
- GitHub for source/documentation
- Future mobile and rider experiences

Specific production technologies should be documented here only when they are actually adopted in the implementation.

## Architecture

```text
                    ┌─────────────────────┐
                    │   Customer Channels │
                    │ Web / Telegram / WA │
                    └──────────┬──────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │   AI Support Layer  │
                    │  Intent + Lookup    │
                    └──────────┬──────────┘
                               │
                               ▼
                    ┌─────────────────────┐
                    │ Approved Data Layer │
                    │ Products / Stock /  │
                    │ Prices / Orders     │
                    └──────────┬──────────┘
                               │
                    ┌──────────┴──────────┐
                    ▼                     ▼
             ┌─────────────┐      ┌─────────────┐
             │ n8n Workflow │      │ Human/Admin  │
             │ Automation   │      │ Operations   │
             └──────┬──────┘      └─────────────┘
                    │
                    ▼
             Order / Support / Delivery
```

This diagram describes the intended architecture, not a claim that every component is already production-connected.

## Screenshots

Add real screenshots to a future `/screenshots` or `/assets` area when they are available.

Suggested README gallery:

```md
<!-- Add verified project screenshots here -->
![Homepage](./assets/screenshots/homepage.png)
![Product listing](./assets/screenshots/products.png)
![Mobile view](./assets/screenshots/mobile.png)
```

Do not add fabricated screenshots or generated UI images as evidence of completed functionality.

## Development Journey

**Idea → Product Concept → UI/UX → Web Development → AI → Automation → Messaging Integrations → Public Archive**

The repository separates completed/publicly observable work from planned systems so the portfolio remains accurate.

See [`docs/DEVELOPMENT_TIMELINE.md`](docs/DEVELOPMENT_TIMELINE.md).

## Roadmap

### Near Term

- Refine product and category data
- Formalize database schema
- Improve customer flows
- Define authentication and role model
- Establish reliable order-state architecture
- Document deployment and environment configuration

### Next Stage

- Connect real inventory and pricing
- Implement authenticated customer accounts
- Build operational shop/admin dashboards
- Develop rider workflow
- Add controlled AI product lookup
- Prototype messaging integrations

### Future

- Production payment integration
- Real-time order tracking
- Full merchant network
- Scalable delivery operations
- Mobile application
- Advanced analytics
- AI-assisted sales and support automation

## Live Project

**Public web experience:** https://sonagazi-five.vercel.app

The live site currently identifies itself as a **demo experience** and presents the Sonagazi Mart marketplace concept.

## GitHub Repository

**Repository:** https://github.com/rahima8581-ops/Sonagazi-mart-

## Founder

**H.M. Tahsin — Founder & CEO**  
Sonagazi Mart  
Sonagazi, Feni, Bangladesh

**BUILT BY H.M. TAHSIN**

---

## Repository Map

See [`REPOSITORY_MAP.md`](REPOSITORY_MAP.md) for the purpose of every top-level directory.

## Documentation

- [`PROJECT_DOCUMENTATION.md`](docs/PROJECT_DOCUMENTATION.md)
- [`AI_AUTOMATION.md`](docs/AI_AUTOMATION.md)
- [`DEVELOPMENT_TIMELINE.md`](docs/DEVELOPMENT_TIMELINE.md)
- [`BRAND.md`](docs/BRAND.md)
- [`CASE_STUDY.md`](docs/CASE_STUDY.md)

## Security & Privacy

Never commit:

- API keys
- Passwords
- Access tokens
- Private webhook URLs
- Database credentials
- Customer information
- Private operational data

Use environment variables and secret management for sensitive configuration.
