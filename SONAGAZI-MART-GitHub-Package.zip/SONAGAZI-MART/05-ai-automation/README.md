# 05 — AI Automation

AI support, product lookup, sales assistance, n8n workflows, and messaging integration architecture.

See [`docs/AI_AUTOMATION.md`](../docs/AI_AUTOMATION.md).
