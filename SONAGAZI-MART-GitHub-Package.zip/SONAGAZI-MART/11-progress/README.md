# 11 — Progress

Project status archive.

Use this folder to record:
- Completed
- Prototype
- In progress
- Planned
- Blocked
- Future experiments

The project should always distinguish public/demo functionality from future architecture.
