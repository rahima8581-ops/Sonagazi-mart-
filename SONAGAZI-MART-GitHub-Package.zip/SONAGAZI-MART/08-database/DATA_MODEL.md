# Data Model Direction

This is a planning document, not a claim that these tables already exist in production.

## Products

- `id`
- `name`
- `category_id`
- `description`
- `unit`
- `price`
- `discount_price`
- `stock_status`
- `shop_id`
- `image_url`
- `updated_at`

## Categories

- `id`
- `name`
- `slug`
- `description`

## Shops

- `id`
- `name`
- `contact`
- `status`
- `created_at`

## Inventory

- `id`
- `product_id`
- `quantity`
- `availability`
- `updated_at`

## Customers

- `id`
- `name`
- `contact`
- `address`
- `created_at`

Customer data must be protected and should never be committed to this public repository.

## Orders

- `id`
- `customer_id`
- `status`
- `total`
- `delivery_address`
- `created_at`

## Order Items

- `id`
- `order_id`
- `product_id`
- `quantity`
- `unit_price`

## AI Data Access

The AI assistant should receive only the minimum approved data needed to answer a request.
