# 08 — Database

Planned data model for products, stock, prices, users, shops, riders, orders, and automation.

Suggested future entities:
- products
- categories
- shops
- inventory
- customers
- riders
- orders
- order_items
- messages
- promotions

Status: **Planned / architecture stage**
