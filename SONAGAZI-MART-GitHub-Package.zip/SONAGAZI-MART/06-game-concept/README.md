# 06 — Game Concept

**SONAGAZI MART — CITY DELIVERY**

A realistic 3D mobile delivery-simulator concept set in a believable Bangladeshi town environment.

Status: **Concept / experiment**

This folder is not evidence of a completed production game.
