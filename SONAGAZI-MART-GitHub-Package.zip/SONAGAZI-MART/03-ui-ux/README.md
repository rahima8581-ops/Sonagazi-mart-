# 03 — UI/UX

Interface and experience documentation.

Focus areas:
- Customer marketplace
- Product discovery
- Offers
- Cart/order flow
- Mobile presentation
- Future rider/shop/admin surfaces

Add verified screenshots or design exports here as they become available.
