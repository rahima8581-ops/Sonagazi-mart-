# 02 — Branding

Brand identity archive for Sonagazi Mart.

See [`docs/BRAND.md`](../docs/BRAND.md) for the canonical colors, slogan, founder credit, and visual direction.
